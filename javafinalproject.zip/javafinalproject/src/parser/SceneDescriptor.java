package parser;

import java.util.ArrayList;
import java.util.Map;

public class SceneDescriptor {
        public SceneDescriptor(){}
        public void fromXML(String name){

        }
        public Map<String, String> getAmbientLightAttributes(){
                return null;
        }
        public Map<String, String> getCameraAttributes(){
                return null;
        }
        public Map<String, String> getSceneAttributes(){
                return null;
        }
        public ArrayList<Map<String, String>> getSpheres(){
                return null;
        }
        public ArrayList<Map<String, String>> getTriangles(){
                return null;
        }
}
